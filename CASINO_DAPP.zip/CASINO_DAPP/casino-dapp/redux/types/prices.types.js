export const SET_PRICE = 'SET_PRICE'
